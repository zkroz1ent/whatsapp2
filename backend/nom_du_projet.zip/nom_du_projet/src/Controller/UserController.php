<?php
// src/Controller/UserController.php

namespace App\Controller;

use App\Entity\User;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

class UserController extends AbstractController
{
    /**
     * @Route("/api/users", name="api_users_list", methods={"GET"})
     */
    public function list(): JsonResponse
    {
        $users = $this->getDoctrine()->getRepository(User::class)->findAll();
        $data = $this->get('serializer')->serialize($users, 'json');

        return new JsonResponse($data, Response::HTTP_OK, [], true);
    }
}

?>