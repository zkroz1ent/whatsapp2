<?php
/// src/Controller/CommissionController.php
namespace App\Controller;

use App\Entity\Commission;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

class CommissionController extends AbstractController
{
    /**
     * @Route("/api/commissions", name="api_commissions_list", methods={"GET"})
     */
    public function list(EntityManagerInterface $em): JsonResponse
    {
        $commissions = $em->getRepository(Commission::class)->findAll();
        $data = $this->get('serializer')->serialize($commissions, 'json', ['groups' => 'commission:read']);
        return new JsonResponse($data, JsonResponse::HTTP_OK, [], true);
    }
}
?>