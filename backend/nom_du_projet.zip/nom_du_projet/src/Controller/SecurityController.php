<?php
// src/Controller/SecurityController.php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class SecurityController extends AbstractController
{
    /**
     * @Route("/api/login", name="api_login", methods={"POST"})
     */
    public function login(): Response
    {
        // La gestion de la connexion sera automatiquement prise en charge par Symfony Security
        throw new \Exception('Don\'t forget to activate logout in security.yaml and implement refreshToken method');
    }

    /**
     * @Route("/api/logout", name="api_logout", methods={"GET"})
     */
    public function logout(): void
    {
        // Le fournisseur d'authentification de Symfony appellera cette méthode
        throw new \Exception('Don\'t forget to activate logout in security.yaml');
    }
}
?>